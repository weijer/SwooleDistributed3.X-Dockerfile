<?php
namespace Home\Controller;

use Common\Controller\VerifyController;

class DirtyDataController extends VerifyController
{

}