<?php

namespace Api\Controller;


class ClientNoteController extends BaseController
{

}
