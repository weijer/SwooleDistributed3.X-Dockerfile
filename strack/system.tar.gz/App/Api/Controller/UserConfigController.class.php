<?php

namespace Api\Controller;


class UserConfigController extends BaseController
{

}
