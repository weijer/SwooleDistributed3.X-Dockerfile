<?php

namespace Api\Controller;


class TimelogIssueController extends BaseController
{

}
