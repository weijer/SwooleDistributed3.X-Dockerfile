<?php

namespace Api\Controller;


class HorizontalController extends BaseController
{

}
