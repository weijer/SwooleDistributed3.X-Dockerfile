<?php

namespace Api\Controller;


class ClientSessionController extends BaseController
{

}
