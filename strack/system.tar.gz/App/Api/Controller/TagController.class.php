<?php

namespace Api\Controller;


class TagController extends BaseController
{

}
