<?php

namespace Api\Controller;


class OauthCodeController extends BaseController
{

}
