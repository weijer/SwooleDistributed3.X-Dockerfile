<?php

namespace Api\Controller;


class MemberController extends BaseController
{

}
