<?php

namespace Api\Controller;


class UserController extends BaseController
{
}
