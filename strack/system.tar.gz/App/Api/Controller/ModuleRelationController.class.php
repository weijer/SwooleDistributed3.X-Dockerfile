<?php

namespace Api\Controller;


class ModuleRelationController extends BaseController
{

}
