<?php

namespace Api\Controller;


class DepartmentController extends BaseController
{

}
