<?php

namespace Api\Controller;


class FileTypeController extends BaseController
{

}
