<?php

namespace Api\Controller;


class OauthTokenController extends BaseController
{

}
