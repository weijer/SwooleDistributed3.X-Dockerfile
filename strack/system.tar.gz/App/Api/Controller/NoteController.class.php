<?php

namespace Api\Controller;

class NoteController extends BaseController
{

}