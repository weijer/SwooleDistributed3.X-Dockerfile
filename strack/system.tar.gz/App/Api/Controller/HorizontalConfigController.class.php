<?php

namespace Api\Controller;


class HorizontalConfigController extends BaseController
{

}
