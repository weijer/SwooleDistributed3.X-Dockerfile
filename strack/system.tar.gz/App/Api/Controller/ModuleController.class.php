<?php

namespace Api\Controller;

class ModuleController extends BaseController
{

}
