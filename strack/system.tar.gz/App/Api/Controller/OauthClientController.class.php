<?php

namespace Api\Controller;


class OauthClientController extends BaseController
{

}
