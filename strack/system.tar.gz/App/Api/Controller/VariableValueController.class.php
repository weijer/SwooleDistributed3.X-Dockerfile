<?php

namespace Api\Controller;


class VariableValueController extends BaseController
{

}
