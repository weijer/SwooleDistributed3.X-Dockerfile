<?php

namespace Api\Controller;


class  ReviewLinkController extends BaseController
{

}