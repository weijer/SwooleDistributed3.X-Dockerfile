<?php

namespace Api\Controller;

class EventController extends BaseController
{

}