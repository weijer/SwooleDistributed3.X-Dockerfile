<?php

namespace Api\Controller;


class CommonActionController extends BaseController
{

}
