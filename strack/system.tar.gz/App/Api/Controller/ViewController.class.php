<?php

namespace Api\Controller;


class ViewController extends BaseController
{

}