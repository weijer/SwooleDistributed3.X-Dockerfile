<?php

namespace Api\Controller;

class StatusController extends BaseController
{

}