<?php

namespace Common\Api;

class UserApi extends \Think\Model
{
    /**
     * 测试
     */
    public function test()
    {

    }
}