<?php
return [
    'app_begin' => ['Behavior\CheckLangBehavior']
];