<?php
return [
    'Queue\Command\EventCommand', // 执行事件
    'Queue\Command\MessageCommand', // 执行消息命令
    'Queue\Command\ExcelCommand' // 执行导出Excel任务
];