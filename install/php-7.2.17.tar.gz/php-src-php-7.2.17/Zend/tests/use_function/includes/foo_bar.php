<?php

namespace foo;

function bar() {
    return 'local bar';
}
